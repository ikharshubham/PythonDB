import pymysql

con=pymysql.connect(host='brbang7ptwbwrawyyiwz-mysql.services.clever-cloud.com', user='usmpfqhfpd9xlwzo', password='YH5C0D08SgCHR9rNXT5Y', database='brbang7ptwbwrawyyiwz')
curs=con.cursor()

cod=int(input('Enter Book Code: '))

curs.execute("select * from books where bookcd=%d" %cod)
data=curs.fetchone()

try:
    print('%s | %s | %s | %s | %d | %.02f | %s' %(data[1],data[2],data[3],data[4],data[5],data[6],data[7]))
except:
    print('Book not found')

con.close
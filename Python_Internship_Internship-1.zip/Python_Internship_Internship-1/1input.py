import pymysql

con=pymysql.connect(host='brbang7ptwbwrawyyiwz-mysql.services.clever-cloud.com', user='usmpfqhfpd9xlwzo', password='YH5C0D08SgCHR9rNXT5Y', database='brbang7ptwbwrawyyiwz')
curs=con.cursor()

cod=int(input('Enter Book Code: '))
nam=input('Enter Book Name: ')
cat=input('Enter Book Category: ')
aut=input('Enter Book Auther Name: ')
pbn=input('Enter Book Publication: ')
edn=int(input('Enter Book Edition: '))
prc=float(input('Enter Book Price: '))
rev=input('Enter Book Review: ')

try:
    curs.execute("insert into books values(%d,'%s','%s','%s','%s',%d,%.2f,'%s')" %(cod,nam,cat,aut,pbn,edn,prc,rev))
    con.commit()
    print('Book is added successfully')
except Exception as e:
    print('Data insert failed',e)

con.close()
import pymysql

con=pymysql.connect(host='brbang7ptwbwrawyyiwz-mysql.services.clever-cloud.com', user='usmpfqhfpd9xlwzo', password='YH5C0D08SgCHR9rNXT5Y', database='brbang7ptwbwrawyyiwz')
curs=con.cursor()

curs.execute("select * from books")
data=curs.fetchall()

print(data)

con.close
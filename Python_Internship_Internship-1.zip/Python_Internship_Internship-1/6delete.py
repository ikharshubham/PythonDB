import pymysql

con=pymysql.connect(host='brbang7ptwbwrawyyiwz-mysql.services.clever-cloud.com', user='usmpfqhfpd9xlwzo', password='YH5C0D08SgCHR9rNXT5Y', database='brbang7ptwbwrawyyiwz')
curs=con.cursor()

cod=int(input('Enter Book Code: '))

curs.execute("select * from books where bookcd=%d" %cod)
data=curs.fetchone()

print(data)

print('Do you want to delete?')
ans=input()
if ans.lower()=='yes':
    curs.execute("delete from books where bookcd=%d" %cod)
    con.commit()
    print('Book is delete successfully')
else:    
    print('Book is not deleted')

con.close()    
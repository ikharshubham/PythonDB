import pymysql

con=pymysql.connect(host='brbang7ptwbwrawyyiwz-mysql.services.clever-cloud.com', user='usmpfqhfpd9xlwzo', password='YH5C0D08SgCHR9rNXT5Y', database='brbang7ptwbwrawyyiwz')
curs=con.cursor()

aut=input('Enter Book Auther Name: ')
pbn=input('Enter Book Publication: ')

curs.execute("select * from books where bookau='%s' and bookpb='%s'" %(aut,pbn))
data=curs.fetchall()

try:
    for rec in data:
       print('%s' %(rec[1]))
except:
    print('Combination is not match')      

con.close
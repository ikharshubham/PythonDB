import pymysql

con=pymysql.connect(host='brbang7ptwbwrawyyiwz-mysql.services.clever-cloud.com', user='usmpfqhfpd9xlwzo', password='YH5C0D08SgCHR9rNXT5Y', database='brbang7ptwbwrawyyiwz')
curs=con.cursor()

cat=input('Enter Book Category: ')

curs.execute("select * from books where bookct='%s'" %cat)
data=curs.fetchall()

for rec in data:
    print('%s' %(rec[1]))
con.close
import pymysql

con=pymysql.connect(host='brbang7ptwbwrawyyiwz-mysql.services.clever-cloud.com', user='usmpfqhfpd9xlwzo', password='YH5C0D08SgCHR9rNXT5Y', database='brbang7ptwbwrawyyiwz')
curs=con.cursor()

cod=int(input('Enter Book Code: '))

curs.execute("select * from books where bookcd=%d" %cod)
data=curs.fetchone()
 
print(data)

print('Review the book: ') 
rw=input()
curs.execute("Update books set review='%s' where bookcd=%d" %(rw,cod))
con.commit()
print('Review added succesfully')

con.close()